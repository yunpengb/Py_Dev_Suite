a = {1,2,"cat",(3,4)}
b = {1,3,"dog",[3,4]}

print a,b