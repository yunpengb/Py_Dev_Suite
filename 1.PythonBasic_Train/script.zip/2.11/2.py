a = {1,2,"cat",(3,4)}
b = {1,3,"dog"}

print 1 in a
print 10 in b,"\n----------"

print a > b
print a < b,"\n==========="

print a & b
print a - b
print b - a
print a | b