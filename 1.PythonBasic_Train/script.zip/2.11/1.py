a = {1,2,"cat"}
b = {1}

print len(a),len(b),"\n"

b.add("dog")
print b,"#---------"

b.remove("dog")
print b