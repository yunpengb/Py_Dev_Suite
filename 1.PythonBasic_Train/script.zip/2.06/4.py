a = 1
print id(a)

b = "HAHA"
print id(b)

a = 2
print id(a)
