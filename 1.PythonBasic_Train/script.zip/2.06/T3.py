a = 2
b = 2
c = b

print a is b
print a is c