a = 1
a += 2
print a

a = 1
a *= 2
print a

a = 1
a -= 2
print a

a = 10
a /= 2
print a