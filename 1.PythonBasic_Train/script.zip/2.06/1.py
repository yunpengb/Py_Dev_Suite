c = "Hello World!"
e = c * 2
print "result is:"
print e
print "\n"

e = c + 1
print e