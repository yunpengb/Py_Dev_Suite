a = "HAHA"
b = "HAHA"
c = b

print a is b
print a is c