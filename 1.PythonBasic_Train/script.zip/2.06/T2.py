a = 2.5
b = 2.5
c = b

print id(a)
print id(b)

print a is b
print a is c