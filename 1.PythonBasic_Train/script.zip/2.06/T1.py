a = 1
print id(a)

a = 2
print id(a)

b = 2
print id(b)