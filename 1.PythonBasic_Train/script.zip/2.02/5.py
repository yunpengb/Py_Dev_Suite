name1 = raw_input("Please input your name:")
pswd =  raw_input("Please input your password:")
print "OK! your account is ID:[%s]-password:[%s]" % (name1,pswd)