a = raw_input("Please input a number:")
print "Your input is [%s]" % a3