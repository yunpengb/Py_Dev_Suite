num1 = raw_input("Please input first number:")
num2 =  raw_input("Please input second number:")
print "add result is:[%d]" % (int(num1) + int(num2))