print "Please input a number:",
a = raw_input()
print a