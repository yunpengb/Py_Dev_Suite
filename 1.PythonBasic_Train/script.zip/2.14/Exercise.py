for i in range(21):
    if i == 4 or i == 6:
        continue
    elif i % 2 == 0:
        print i,