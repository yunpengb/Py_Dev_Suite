i = 10
while i > 0:
    if i == 3:
       break
    print i
    i -= 1