file1 = open("D:\\temp1\\write.txt",'w')
file1.writelines (['first','HAHA','3'])
file1.close()