file1 = open("D:\\temp1\\read.txt",'r')
a = file1.readlines()
print a
print type(a)
file1.close()