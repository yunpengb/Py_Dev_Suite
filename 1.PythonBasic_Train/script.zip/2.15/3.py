file1 = open("D:\\temp1\\write.txt",'w')
file1.write("JOBS\nBill\n3\nYao\nMax")
file1.close()