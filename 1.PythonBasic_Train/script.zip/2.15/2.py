file1 = open("D:\\temp1\\read.txt",'r')
a = file1.read()
print a
print type(a)
file1.close()