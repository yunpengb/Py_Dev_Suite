a = "hello"
b = "world!"
print a + " " + b