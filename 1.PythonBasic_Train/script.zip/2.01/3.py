a = "hello"
b = "world!"
c = "1"
d = "2"
e = "3"
f = "go"
print a,b,c,d,e,f