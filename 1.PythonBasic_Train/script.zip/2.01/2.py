a = "hello world!"
print a