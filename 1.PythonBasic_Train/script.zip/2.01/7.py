formatter = "Test for %s/%s time"
print formatter % ("1","10")
print formatter % ("2","10") 
print formatter % ("3","10") 
print formatter % ("4","10") 
print formatter % ("5","10") 