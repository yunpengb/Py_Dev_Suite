print "Test for %s/%s time" % ("2","5")
print "Test for %d/%d time" % (2,5)