a = (1,2,3,4,5,6,7,8,9)
print type(a)

print a[0]
print len(a)
print a + ("X","Y")
print a * 2
print 3 in a

a[0] = "HAHA"