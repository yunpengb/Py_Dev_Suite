a = (1,2,3,["X","Y"])
a[3][1] = "HAHA"

print a