a = None
b = 1
c = 1.1
d = True
e = "Jobs"
f = (1,1,"Bill Gates")

g = [1,1,"Bill Gates"]
h = {"YaoMing":226,"Jobs":188}
i = {1,2,"Bill Gates"}

for i in [a,b,c,d,e,f,g,h,i]:
    print type(i)
