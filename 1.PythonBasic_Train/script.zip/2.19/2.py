a = [1,2,3,4]
sum = 0
for i in range(len(a)):
    sum += a[i]
print sum