a = [1,2,3,4]
print sum(a)