dict1 = {"Yao":226,"AQ":150}

print "Yao" in dict1