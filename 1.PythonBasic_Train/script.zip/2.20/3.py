a = "applea"
print a.index("a")
print a.index("p")
print a.index("l")