# coding: UTF-8

a = ["a","b","c"]
for i,j in enumerate(a):
    print i,j
#---------------------------------    
print "---------------"
#�ȼ��ڣ�
a = ["a","b","c"]
for i in range(len(a)):
    print i,a[i]
