list1 = ["hello","every","8","D"]
a = "_".join(list1)
print a