a = "Hello World!"
b = "_HAHA"

print a + b
print a * 2 + b