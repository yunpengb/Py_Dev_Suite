a = "Hello World!"
print a[:3]
print a[0:3]
print a[3:]
print a[-1]
print a[-9:]