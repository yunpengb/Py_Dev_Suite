a = "Hello World!"
print a[0],a[1],a[-1]