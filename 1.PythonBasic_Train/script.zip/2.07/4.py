a = "Hello World!"
b = "_HAHA"

print "He" in a
print "_" not in b

c = "ERR:setup carrier failed"
if "ERR" in c:
    print "+_+:ERR appear,sth is wrong" 
