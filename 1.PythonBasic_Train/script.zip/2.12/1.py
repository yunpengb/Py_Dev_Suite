a = [1,1.1,True,False,1L,3+4j,-3.1-4.1j]

for i in a:
    print type(i)