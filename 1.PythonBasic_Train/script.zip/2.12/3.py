a = -3.1-4.1j

print a.real
print a.imag
print a.conjugate()