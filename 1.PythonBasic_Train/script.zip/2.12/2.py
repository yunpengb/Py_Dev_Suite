a = True
b = 1
c = 99

print a + b
print a + c