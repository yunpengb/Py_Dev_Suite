a = range(3)
print a

b = range(0,8,2)
print b

c = range(9,1,2)
print c

d = range(9,1,-2)
print d