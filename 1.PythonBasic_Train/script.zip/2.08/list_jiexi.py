a = [i for i in range(8) if i % 2 == 0]
print a

b = [j for j in range(20) if j % 3 == 0]
print b