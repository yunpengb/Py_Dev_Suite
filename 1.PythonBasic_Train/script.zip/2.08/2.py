a = [1,2,3,4,3]

a.append("HAHA")
print a
print a.count(3)

a.remove(3)
print a

#--------del by num----------
a = [1,2,3,4,3]
del a[1]
print a

a = [1,2,3,4,3]
a.pop(1)
print a
