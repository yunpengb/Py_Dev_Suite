a = [1,2,3,4,5,6,7,8,9]
print a[5]
print a[-9]

a[0] = "HAHA"
print a
print a[2:3],"--------"
print len(a),"~~~~~~~~"
print a + ["X","Y"]
print a * 2
print 5 in a,"================================"
a[0] = [1,2,3]
print a