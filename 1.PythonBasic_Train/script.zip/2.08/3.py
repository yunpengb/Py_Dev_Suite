a = ['c','b','a','apple','d']
a.sort()
print a
a.reverse()
print a


b = [1,10,4,100,7,2,3]
b.sort()
print b
b.reverse()
print b