print 5 > 4
print 5 < 4
print 5 > 5
print 5 != 5