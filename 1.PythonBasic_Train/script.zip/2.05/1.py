a = 3
b = 2
c = 2.0

print a + b,a - b,a * b
print '\n'

print a / b
print a / c
print a // b
print a // c