print 4 > 2 and 5 > 5
print 4 < 2 or 5 > 5
print not 5 > 5