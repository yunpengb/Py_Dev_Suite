a = 1
# print a

'''
print a + 2
'''

print a + 1