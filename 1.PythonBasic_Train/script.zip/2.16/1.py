a = 1
b = "HAHA"
print a + b