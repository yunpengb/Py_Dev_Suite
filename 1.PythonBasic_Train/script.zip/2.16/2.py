b = [1,"HAHA",3,4,5]
a = 2
for i in range(len(b)):
    print a + b[i]